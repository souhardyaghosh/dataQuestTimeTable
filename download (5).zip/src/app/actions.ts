"use server";

import {
  generateOptimalTimetable,
  GenerateOptimalTimetableInput,
} from "@/ai/flows/generate-optimal-timetable";
import {
  resolveSchedulingConflicts,
  ResolveSchedulingConflictsInput,
} from "@/ai/flows/resolve-scheduling-conflicts";

export async function generateTimetableAction(
  input: GenerateOptimalTimetableInput
) {
  try {
    const result = await generateOptimalTimetable(input);
    return { success: true, data: result };
  } catch (error) {
    console.error(error);
    return { success: false, error: "Failed to generate timetable." };
  }
}

export async function resolveConflictsAction(
  input: ResolveSchedulingConflictsInput
) {
  try {
    const result = await resolveSchedulingConflicts(input);
    return { success: true, data: result };
  } catch (error) {
    console.error(error);
    return { success: false, error: "Failed to resolve conflicts." };
  }
}
