
'use client'

import { TimetableGenerator } from "@/components/timetable-generator";
import { getUserData } from "@/lib/demo-data";
import { useSearchParams, useRouter } from "next/navigation";
import { Suspense } from "react";
import { Loader, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

function FacultySchedulePageContent() {
    const router = useRouter();
    const searchParams = useSearchParams();
    const userId = searchParams.get('userId');

    if (!userId) {
        router.push('/');
        return null;
    }

    const userData = getUserData(userId);

    if (!userData || userData.role !== 'faculty') {
        return (
            <div className="flex flex-col items-center justify-center h-screen">
                <p>Invalid user or role.</p>
                <Button onClick={() => router.push('/')} className="mt-4">Go to Login</Button>
            </div>
        );
    }
    
    // We need to adapt the TimetableGenerator to work for faculty
    // For now, let's just pass the necessary data
    const adaptedUserData = {
        ...userData,
        courseList: userData.courses.map(c => ({ name: c.name, details: c.code, credits: c.credits})),
    }

    return (
        <main className="min-h-screen bg-gray-50 dark:bg-gray-900 text-gray-800 dark:text-gray-200">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-7xl pb-16">
                <header className="py-6">
                    <Button variant="ghost" onClick={() => router.back()}>
                        <ArrowLeft className="mr-2 h-4 w-4" />
                        Back to Dashboard
                    </Button>
                </header>
                 <TimetableGenerator userData={adaptedUserData} />
            </div>
        </main>
    );
}


export default function FacultySchedulePage() {
    return (
        <Suspense fallback={<div className="flex h-screen w-full items-center justify-center bg-gray-50 dark:bg-gray-900"><Loader className="h-8 w-8 animate-spin text-purple-600" /></div>}>
            <FacultySchedulePageContent />
        </Suspense>
    )
}
