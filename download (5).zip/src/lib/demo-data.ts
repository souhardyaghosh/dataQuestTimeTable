
export type DemoUser = {
  id: string;
  name: string;
  email: string;
  password: string;
  role: 'student' | 'faculty';
};

export type Course = {
  name: string;
  details: string;
  credits: number;
};

export type StudentStats = {
  cumulativeScore: { score: number; total: number };
  cgpa: { score: number; total: number };
  attendance: { score: number; total: number };
  culturalActivities: { score: number; total: number };
}

export type Achievement = {
  name: string;
  status: 'Earned' | 'Locked';
  icon: 'Clock' | 'Trophy' | 'Target' | 'Award';
};

export type StudentData = {
  role: 'student';
  name: string;
  courseInformation: string;
  courseList: Course[];
  stats: StudentStats;
  achievements: Achievement[];
};

export type FacultyCourse = {
  name: string;
  code: string;
  studentsEnrolled: number;
  credits: number;
  rating: number;
};

export type FacultyStats = {
  totalStudents: number;
  averageRating: number;
  activeCourses: number;
  weeklyHours: number;
};

export type FacultyData = {
  role: 'faculty';
  name: string;
  stats: FacultyStats;
  courses: FacultyCourse[];
  teachingPreferences: {
    availableSlots: string[];
    teachingStyle: string[];
  },
  courseInformation: string;
  // This is needed for TimetableGenerator props
  courseList: {name: string, details: string, credits: number}[];
};

export type UserData = StudentData | FacultyData;


export const demoUsers: DemoUser[] = [
  // Students
  { id: 's1', name: 'Alice Johnson', email: 'alice@university.edu', password: 'password123', role: 'student' },
  { id: 's2', name: 'Bob Williams', email: 'bob@university.edu', password: 'password123', role: 'student' },
  { id: 's3', name: 'Charlie Brown', email: 'charlie@university.edu', password: 'password123', role: 'student' },
  { id: 's4', name: 'Diana Miller', email: 'diana@university.edu', password: 'password123', role: 'student' },
  { id: 's5', name: 'Eve Davis', email: 'eve@university.edu', password: 'password123', role: 'student' },
  // Faculty
  { id: 'f1', name: 'Dr. Smith', email: 'smith@university.edu', password: 'faculty123', role: 'faculty' },
  { id: 'f2', name: 'Prof. Doe', email: 'doe@university.edu', password: 'faculty123', role: 'faculty' },
  { id: 'f3', name: 'Dr. Jones', email: 'jones@university.edu', password: 'faculty123', role: 'faculty' },
  { id: 'f4', name: 'Prof. Stark', email: 'stark@university.edu', password: 'faculty123', role: 'faculty' },
  { id: 'f5', name: 'Dr. Banner', email: 'banner@university.edu', password: 'faculty123', role: 'faculty' },
];

const allCourses = {
  cs101: { info: "- Course: Computer Science Basics (CS101), Year: 1, Branch: Computer Science, Duration: 1 hour, Lecturer: Dr. Smith, Location: Hall A", list: { name: "Computer Science Basics", details: "CS101", credits: 4 }},
  ma101: { info: "- Course: Advanced Mathematics (MATH301), Year: 1, Branch: All, Duration: 1 hour, Lecturer: Prof. Doe, Location: Room 201", list: { name: "Advanced Mathematics", details: "MATH301", credits: 4 }},
  phy101: { info: "- Course: Physics Fundamentals (PHYS201), Year: 1, Branch: All, Duration: 2 hours, Lecturer: Dr. Jones, Location: Lab 3", list: { name: "Physics Fundamentals", details: "PHYS201", credits: 3 }},
  ee101: { info: "- Course: Basic Electrical Engineering (EE101), Year: 1, Branch: Electrical, Duration: 1 hour, Lecturer: Prof. Stark, Location: EE Building", list: { name: "Basic Electrical Engineering", details: "EE101", credits: 3 }},
  ch101: { info: "- Course: Chemistry Lab (CHEM151), Year: 1, Branch: All, Duration: 1 hour, Lecturer: Dr. Banner, Location: Chem Lab", list: { name: "Chemistry Lab", details: "CHEM151", credits: 2 }},
  cs201: { info: "- Course: Data Structures (CS201), Year: 2, Branch: Computer Science, Duration: 1 hour, Lecturer: Dr. Smith, Location: Hall B", list: { name: "Data Structures", details: "CS201", credits: 3 }},
  ma201: { info: "- Course: Linear Algebra (MA201), Year: 2, Branch: All, Duration: 1 hour, Lecturer: Prof. Doe, Location: Room 202", list: { name: "Linear Algebra", details: "MA201", credits: 3 }},
  me101: { info: "- Course: Intro to Mechanics (ME101), Year: 1, Branch: Mechanical, Duration: 2 hours, Lecturer: Dr. Banner, Location: Mech Hall", list: { name: "Intro to Mechanics", details: "ME101", credits: 4 }},
};

const facultyCourseList: Record<string, { courses: FacultyCourse[], courseInformation: string, courseList: Course[] }> = {
    f1: {
        courses: [
            { name: "Computer Science Basics", code: "CS101", studentsEnrolled: 120, credits: 4, rating: 4.8 },
            { name: "Data Structures", code: "CS201", studentsEnrolled: 90, credits: 3, rating: 4.9 },
        ],
        courseInformation: [allCourses.cs101.info, allCourses.cs201.info].join('\n'),
        courseList: [allCourses.cs101.list, allCourses.cs201.list]
    },
    f2: {
        courses: [
            { name: "Advanced Mathematics", code: "MATH301", studentsEnrolled: 150, credits: 4, rating: 4.7 },
            { name: "Linear Algebra", code: "MA201", studentsEnrolled: 110, credits: 3, rating: 4.6 },
        ],
        courseInformation: [allCourses.ma101.info, allCourses.ma201.info].join('\n'),
        courseList: [allCourses.ma101.list, allCourses.ma201.list]
    },
    f3: {
        courses: [
            { name: "Physics Fundamentals", code: "PHYS201", studentsEnrolled: 180, credits: 3, rating: 4.5 },
        ],
        courseInformation: [allCourses.phy101.info].join('\n'),
        courseList: [allCourses.phy101.list]
    },
    f4: {
        courses: [
            { name: "Basic Electrical Engineering", code: "EE101", studentsEnrolled: 80, credits: 3, rating: 4.8 },
        ],
        courseInformation: [allCourses.ee101.info].join('\n'),
        courseList: [allCourses.ee101.list]
    },
    f5: {
        courses: [
            { name: "Chemistry Lab", code: "CHEM151", studentsEnrolled: 200, credits: 2, rating: 4.4 },
            { name: "Intro to Mechanics", code: "ME101", studentsEnrolled: 75, credits: 4, rating: 4.6 },
        ],
        courseInformation: [allCourses.ch101.info, allCourses.me101.info].join('\n'),
        courseList: [allCourses.ch101.list, allCourses.me101.list]
    },
};


const userCourseData: Record<string, UserData> = {
  s1: {
    role: 'student',
    name: 'Alice Johnson',
    courseInformation: [allCourses.cs101.info, allCourses.ma101.info, allCourses.phy101.info, allCourses.ch101.info, allCourses.cs201.info].join('\n'),
    courseList: [allCourses.cs101.list, allCourses.ma101.list, allCourses.phy101.list, allCourses.ch101.list, allCourses.cs201.list],
    stats: {
      cumulativeScore: { score: 25.5, total: 30 },
      cgpa: { score: 8.5, total: 10 },
      attendance: { score: 9.2, total: 10 },
      culturalActivities: { score: 7, total: 10 },
    },
    achievements: [
      { name: 'Regular Attendee', status: 'Earned', icon: 'Clock' },
      { name: 'Top Performer', status: 'Earned', icon: 'Trophy' },
      { name: 'Well Rounded', status: 'Locked', icon: 'Target' },
      { name: 'Course Master', status: 'Earned', icon: 'Award' },
    ]
  },
  s2: {
    role: 'student',
    name: 'Bob Williams',
    courseInformation: [allCourses.cs201.info, allCourses.ma201.info, allCourses.ee101.info].join('\n'),
    courseList: [allCourses.cs201.list, allCourses.ma201.list, allCourses.ee101.list],
     stats: {
      cumulativeScore: { score: 28, total: 30 },
      cgpa: { score: 9.1, total: 10 },
      attendance: { score: 9.8, total: 10 },
      culturalActivities: { score: 8, total: 10 },
    },
    achievements: [
      { name: 'Regular Attendee', status: 'Earned', icon: 'Clock' },
      { name: 'Top Performer', status: 'Locked', icon: 'Trophy' },
      { name: 'Well Rounded', status: 'Earned', icon: 'Target' },
      { name: 'Course Master', status: 'Locked', icon: 'Award' },
    ]
  },
  s3: {
    role: 'student',
    name: 'Charlie Brown',
    courseInformation: [allCourses.me101.info, allCourses.ma101.info, allCourses.phy101.info, allCourses.ch101.info].join('\n'),
    courseList: [allCourses.me101.list, allCourses.ma101.list, allCourses.phy101.list, allCourses.ch101.list],
    stats: {
      cumulativeScore: { score: 22, total: 30 },
      cgpa: { score: 7.5, total: 10 },
      attendance: { score: 8.5, total: 10 },
      culturalActivities: { score: 9, total: 10 },
    },
     achievements: [
      { name: 'Regular Attendee', status: 'Locked', icon: 'Clock' },
      { name: 'Top Performer', status: 'Locked', icon: 'Trophy' },
      { name: 'Well Rounded', status: 'Earned', icon: 'Target' },
      { name: 'Course Master', status: 'Earned', icon: 'Award' },
    ]
  },
  s4: {
    role: 'student',
    name: 'Diana Miller',
    courseInformation: [allCourses.cs101.info, allCourses.ma201.info, allCourses.ee101.info].join('\n'),
    courseList: [allCourses.cs101.list, allCourses.ma201.list, allCourses.ee101.list],
    stats: {
      cumulativeScore: { score: 26, total: 30 },
      cgpa: { score: 8.8, total: 10 },
      attendance: { score: 9.0, total: 10 },
      culturalActivities: { score: 6, total: 10 },
    },
     achievements: [
      { name: 'Regular Attendee', status: 'Earned', icon: 'Clock' },
      { name: 'Top Performer', status: 'Earned', icon: 'Trophy' },
      { name: 'Well Rounded', status: 'Earned', icon: 'Target' },
      { name: 'Course Master', status: 'Locked', icon: 'Award' },
    ]
  },
  s5: {
    role: 'student',
    name: 'Eve Davis',
    courseInformation: [allCourses.cs101.info, allCourses.cs201.info, allCourses.ma101.info, allCourses.ma201.info].join('\n'),
    courseList: [allCourses.cs101.list, allCourses.cs201.list, allCourses.ma101.list, allCourses.ma201.list],
    stats: {
      cumulativeScore: { score: 24, total: 30 },
      cgpa: { score: 8.2, total: 10 },
      attendance: { score: 9.5, total: 10 },
      culturalActivities: { score: 5, total: 10 },
    },
    achievements: [
      { name: 'Regular Attendee', status: 'Earned', icon: 'Clock' },
      { name: 'Top Performer', status: 'Locked', icon: 'Trophy' },
      { name: 'Well Rounded', status: 'Locked', icon: 'Target' },
      { name: 'Course Master', status: 'Locked', icon: 'Award' },
    ]
  },
  f1: { 
    role: 'faculty', 
    name: 'Dr. Smith',
    stats: { totalStudents: facultyCourseList.f1.courses.reduce((sum, c) => sum + c.studentsEnrolled, 0), averageRating: 4.6, activeCourses: 2, weeklyHours: 18 },
    courses: facultyCourseList.f1.courses,
    teachingPreferences: { availableSlots: ['Morning'], teachingStyle: ['Fast-paced', 'Real-world focused', 'Question-heavy'] },
    courseInformation: facultyCourseList.f1.courseInformation,
    courseList: facultyCourseList.f1.courseList,
  },
  f2: { 
    role: 'faculty', 
    name: 'Prof. Doe',
    stats: { totalStudents: facultyCourseList.f2.courses.reduce((sum, c) => sum + c.studentsEnrolled, 0), averageRating: 4.7, activeCourses: 2, weeklyHours: 20 },
    courses: facultyCourseList.f2.courses,
    teachingPreferences: { availableSlots: ['Morning', 'Afternoon'], teachingStyle: ['Slow-paced', 'Theory-focused'] },
    courseInformation: facultyCourseList.f2.courseInformation,
    courseList: facultyCourseList.f2.courseList,
  },
  f3: { 
    role: 'faculty', 
    name: 'Dr. Jones',
    stats: { totalStudents: facultyCourseList.f3.courses.reduce((sum, c) => sum + c.studentsEnrolled, 0), averageRating: 4.5, activeCourses: 1, weeklyHours: 15 },
    courses: facultyCourseList.f3.courses,
    teachingPreferences: { availableSlots: ['Afternoon'], teachingStyle: ['PPT-based', 'Question-heavy'] },
    courseInformation: facultyCourseList.f3.courseInformation,
    courseList: facultyCourseList.f3.courseList,
  },
  f4: { 
    role: 'faculty', 
    name: 'Prof. Stark',
    stats: { totalStudents: facultyCourseList.f4.courses.reduce((sum, c) => sum + c.studentsEnrolled, 0), averageRating: 4.8, activeCourses: 1, weeklyHours: 12 },
    courses: facultyCourseList.f4.courses,
    teachingPreferences: { availableSlots: ['Morning'], teachingStyle: ['Real-world focused', 'Fast-paced'] },
    courseInformation: facultyCourseList.f4.courseInformation,
    courseList: facultyCourseList.f4.courseList,
  },
  f5: { 
    role: 'faculty', 
    name: 'Dr. Banner',
    stats: { totalStudents: facultyCourseList.f5.courses.reduce((sum, c) => sum + c.studentsEnrolled, 0), averageRating: 4.5, activeCourses: 2, weeklyHours: 22 },
    courses: facultyCourseList.f5.courses,
    teachingPreferences: { availableSlots: ['Morning', 'Afternoon'], teachingStyle: ['Slow-paced', 'Real-world focused'] },
    courseInformation: facultyCourseList.f5.courseInformation,
    courseList: facultyCourseList.f5.courseList,
  },
};

const defaultStudentData: StudentData = {
    role: 'student',
    name: 'Alice Johnson',
    courseInformation: [allCourses.cs101.info, allCourses.ma101.info, allCourses.phy101.info, allCourses.ch101.info, allCourses.cs201.info].join('\n'),
    courseList: [allCourses.cs101.list, allCourses.ma101.list, allCourses.phy101.list, allCourses.ch101.list, allCourses.cs201.list],
    stats: {
      cumulativeScore: { score: 25.5, total: 30 },
      cgpa: { score: 8.5, total: 10 },
      attendance: { score: 9.2, total: 10 },
      culturalActivities: { score: 7, total: 10 },
    },
    achievements: [
      { name: 'Regular Attendee', status: 'Earned', icon: 'Clock' },
      { name: 'Top Performer', status: 'Earned', icon: 'Trophy' },
      { name: 'Well Rounded', status: 'Locked', icon: 'Target' },
      { name: 'Course Master', status: 'Earned', icon: 'Award' },
    ]
};

export function getUserData(userId: string | null): UserData | null {
    if (userId && userCourseData[userId]) {
        const data = userCourseData[userId];
        if (data.role === 'faculty') {
            // Ensure courseList is populated for faculty
            const facultyId = userId as keyof typeof facultyCourseList;
            return {
                ...data,
                courseList: facultyCourseList[facultyId].courseList
            }
        }
        return data;
    }
    // Fallback for testing
    if (userId && userId.startsWith('s')) return defaultStudentData;
    if (userId && userId.startsWith('f')) {
      const facultyId = 'f1' as keyof typeof facultyCourseList;
      return { 
        role: 'faculty', 
        name: 'Dr. Smith',
        stats: { totalStudents: facultyCourseList[facultyId].courses.reduce((sum, c) => sum + c.studentsEnrolled, 0), averageRating: 4.6, activeCourses: 2, weeklyHours: 18 },
        courses: facultyCourseList[facultyId].courses,
        teachingPreferences: { availableSlots: ['Morning'], teachingStyle: ['Fast-paced', 'Real-world focused', 'Question-heavy'] },
        courseInformation: facultyCourseList[facultyId].courseInformation,
        courseList: facultyCourseList[facultyId].courseList,
      };
    }
    return defaultStudentData;
}
