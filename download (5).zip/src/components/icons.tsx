
import { GraduationCap, Wand2, type SVGProps } from "lucide-react";

export const Icons = {
  logo: (props: SVGProps<SVGSVGElement>) => (
    <Wand2 {...props} />
  ),
  graduationCap: GraduationCap,
};
